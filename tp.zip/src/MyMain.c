#include <stdio.h>
#include <stdin.h>

int main(void)
{
  //WRITE EVERYTHING YOU WANT HERE !
  printf("coucou\n");
  return 0;

}
