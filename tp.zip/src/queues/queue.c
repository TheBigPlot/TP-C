#include <stdlib.h>

#include "queue.h"
#include "../structs.h"
#include "../lists/list.h"
#include "../alloc.h"


queue* init_queue()
{

  //TODO
  return NULL;

}


void enqueue(queue* q, int elt)
{

  //TODO

}

list* dequeue(queue* q)
{

  //TODO
  return NULL;

}

int isempty(queue* q)
{

  //TODO
  return 0;

}


void FreeQueue(queue* q)
{

  //TODO

}
