#include <stdlib.h>
#include "../structs.h"
#include "list.h"
#include "../alloc.h"



void list_init(list* l)
{
  
  //TODO
  l = NULL;
  
}


list* create_list(int nb)
{

  //TODO
  return NULL;

}


int list_is_empty(list *l)
{

  //TODO
  return 0;

}


size_t list_len(list *l)
{

  //TODO
  return 0;
  
}


list* list_get(list* l, size_t n)
{

  //TODO
  return NULL;

}


void list_push_front(list *l, list *elm)
{

  //TODO

}


void list_push_end(list *l, list *elm)
{

  //TODO

}


void list_insert(list *l, list *elm, size_t n)
{

  //TODO

}


void insert_in_sorted_list(list* l, list* elm)
{

  //TODO

}


list* list_pop_front(list *l)
{

  //TODO
  return NULL;

}

list* list_remove(list* l, size_t n)
{

  //TODO
  return NULL;

}


list* list_search(list* l, int val)
{

  //TODO
  return NULL;

}


list* list_binary_search(list* l, int val)
{

  //TODO
  return NULL;

}

void FreeList(list* l)
{

  //TODO

}
