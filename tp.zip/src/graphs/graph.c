#include <stdlib.h>
#include <stdio.h>

#include "../structs.h"
#include "../lists/list.h"
#include "../queues/queue.h"
#include "../alloc.h"


graph* init_graph()
{

  //TODO
  return NULL;
  
}

void add_edge(graph* G, int src, int dst)
{

  //TODO

}

void add_vertice(graph* G)
{

  //TODO

}

void backedges_dfs(graph* G)
{

  //TODO

}


int components_dfs(graph* G)
{

  //TODO
  return 0;

}

int components_bfs(graph* G)
{

  //TODO
  return 0;

}

list* path(graph* G, int src, int dst)
{

  //TODO
  return NULL;

}


int eccentricity(graph* G, int x)
{

  //TODO
  return 0;

}


list* center(graph* G)
{

  //TODO
  return NULL;

}


void FreeGraph(graph* g)
{

  //TODO

}

