#include <stdio.h>
#include <stdlib.h>
#include "../structs.h"
#include "../alloc.h"

unsigned long power_of_two(int n)
{

  //TODO
  return 0;

}


unsigned long binary_to_int(int bin)
{
  
  //TODO
  return 0;

}

void decompose(int n, int* tab)
{

  //TODO

}


void reverse_arr(int* arr)
{

  //TODO

}

void n_shift_arr(int* arr, size_t length, int n)
{

  //TODO

}

void replace(char* s1, char* s2)
{

  //TODO

}

void cesar(char* s, int dec)
{

  //TODO

}

unsigned long basic_calculator(char* s)
{

  //TODO
  return 0;

}

